# Mypackage
This library was created as an example on how to publish your own python package.

## Building this package localy
'python setup.py sdist'

## Installing this package from Github
'pip install git+ https//github.com/collins/.......'
## Updating this package from Gtithub
'pip install git+ https//github.com/collins/........'